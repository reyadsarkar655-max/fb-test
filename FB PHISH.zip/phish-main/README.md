<p align="center">
    <img width="200" src="https://raw.githubusercontent.com/anbuinfosec/anbuinfosec/refs/heads/main/banner.png" alt="Banner anbuinfosec">
</p>

## Features:
1. Telegram [Bot](https://t.me/BotFather) Log.
2. JSON database
3. [MongoDB](https://cloud.mongodb.com/)
4. Dashboard `/dashboard`

## Setup Video [Here](https://www.facebook.com/groups/517828177563563)

---
## 🌐 Socials:
[![Facebook](https://img.shields.io/badge/Facebook-%231877F2.svg?logo=Facebook&logoColor=white)](https://facebook.com/anbuinfosec3) [![Instagram](https://img.shields.io/badge/Instagram-%23E4405F.svg?logo=Instagram&logoColor=white)](https://instagram.com/anbuinfosec) [![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?logo=linkedin&logoColor=white)](https://linkedin.com/in/anbuinfosec) [![YouTube](https://img.shields.io/badge/YouTube-%23FF0000.svg?logo=YouTube&logoColor=white)](https://youtube.com/akxvau) [![Codepen](https://img.shields.io/badge/Codepen-000000?style=for-the-badge&logo=codepen&logoColor=white)](https://codepen.io/anbuinfosec) 

---