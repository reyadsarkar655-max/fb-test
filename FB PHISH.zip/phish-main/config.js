module.exports = {
    dashboardPassword: "215885",
    logType: "tgBot",
    note: "Change this to 'mongodb', 'tgBot' or 'json' as needed",
    timezone: "Asia/Dhaka",
    bot: {
        token: "7773567660:AAEnS92Xe9BG8q0XqDD7ilPCa1j5Uuhll6Q",
        id: "2017838571",
        note: "Add telegram bot token and chatid for telegram log."
    },
    database: {
        mongodbURL: "mongo_url_here",
        note: "Add your mongodb database url here"
    },
    jsonPath: "./data/submissions.json"
};
